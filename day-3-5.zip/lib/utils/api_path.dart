const info = '/info';

// const login = '/api/v1/user/login';
const login = '';
